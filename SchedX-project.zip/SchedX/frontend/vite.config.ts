import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    proxy: { "/api": { target: "http://127.0.0.1:8000", changeOrigin: true } },
  },
  build: { chunkSizeWarningLimit: 1200 },
  test: { environment: "jsdom", setupFiles: ["./src/test-setup.ts"], globals: true, include: ["src/**/*.test.{ts,tsx}"] },
} as any);
